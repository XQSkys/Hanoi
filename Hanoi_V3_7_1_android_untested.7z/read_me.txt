Hanoi Variation of "Tuerme von Hanoi". 
Spielen benotigen sie Java: https://java.com/de/download/ 
Hanoi_Simple.zip: ohne Filme funktion, ohne Automatisches Speichern. 
Hanoi_Normal.zip: Film funktion, Automatisches Speichern. Hanoi_speciale.zip 
Variante mit spezieller autosave und filme funktion was kostet das? 
ich will dafür kein Geld. die Hanoi_speciale hat eine besonderheit: 
wenn ein beliebiges level aktiv ist zum beispiel 17 steine, werden alles autosave in der eingestellten höhe gespeichert(die zahl die auf dem höhe knopf steht)
 ohne das zuätzlich getan erden muss. das heißt wenn ich level 17 spiele und nur die höhe geändert wird auf dem knopf speichert und läd er von da ensprechen 
 sind alle höhen nummern wie speicher slots/speicherplatze. z.b. ein 19er als 1bild.png speichern und dann alle anderen 18 plätze zum schnell speichern nemen
 nur den start knopf sollte dann nicht gedrückt werden.ein 19er als 1bild.png also "höhe:1" einstellen und er öffnet 1bild.png was ein bild von einem 19er ist.
 trozdem kann es wie gewohnt gespielt werden. die Film knopf ist auch anders bei Hanoi_speciale es wird eine fortlaufene nummer movie##### erzeigt aber der film
 wird immer in der 3savesMovie gespeichert wenn höhe:3 beziehungsweise auf die aktuell eingestellte höhe ohne das sonst was getan werden muss. drückt man auf start
 erzeugt er einen nomalen turm de entspechenden höhe und filmt weiter, soballt die höhe verstellt wird speichert er sofort da weiter. wenn das bei höhe:1 der 19er
 turm wäre spielt ihr den sobalt ihr auf laden klickt. und könnt ihn wie oben beschrieben nutzen. ist eigenlich ganz einfach man muss sich nur etwas umgewöhnen.
 adv steht für advanced und ist ein wenig kompliziert. Die Hanoi zip Für Windows 64Bit. Sie Brauchen Ein Aktuelles Java. Lite heisst das java nicht enthalen ist 
 in diesem Download. Eine Installation des Spiels ist nicht notwendig das Spiel ist sofort Ausfuerbar. Linux/linux ARM x86 und 64bit ist fertig aber ungetestet.
 eine Android version ist geplant, sogar ohne fehler compiliert aber ich kann es nicht testen. Bei Hanoy wird mit der Maus erst auf den untersten Rosa Basis Stein
 geklickt er wechselt dann von dunkelblau nach grün. danach auf den Basis Stein wo der Stein hin soll mit der Maus drüber. ist bereits ein kleinerer stein darauf
 wird der Basis Stein darunter rot. Wenn gesetzen könnte wird er blau. dann einfach darauf klicken. Es kann jederzeit Gespeichert werden. wichtig ist das Kein Turm
 von dem genommen worden sollte aktiv ist bevor geladen wird. das kann sonst, noch, dazu führen das nach dem laden der alte stein noch im speicher ist. und fehlerhaft
 gesetzt wird. Ist Kein Spielstand vorhanden Wird der Ladebutten beim anklicken rot. Nach erfolgreichen speichern wird der Save button kurz Hellblau. Ist der Aktiven
 Turm von dem Genommen werden sollte, doch nicht der richtige, kann der Basis stein einfach noch einmal angeklickt werden. in der recht Seite finden sich der button
 "Höhe" den kann durch anklicken auf bis zu 19 hoch gestellet werden und dann wechselt er wieder auf 1. Ist die gewünschte Steinzahl eigestellt. auf den unteren Start
 Butten klicken. Das ist dann sofort nach dem klicken Spielbar. beim klicken auf "normal" wechselt Der knopf zu Chaos. Durch klicken start wird ensprechend der eingestellten
 turmhöhe die ensprechende anzahl der steine zufällig auf die 3 Basissteine verteilt . Ziel isz es den Turm auf der Rechten seite Aufzubauen. Da der Spielstand eine Normale
 PNG bBildatei ist können sie ihn mit einem Bildbearbeitungs Programm bearbeiten. das funktioniert halbwegs dann damit zu spielen. Z.B. bei Paint in einem fenster einen
 Stein bemahlen und speichern und im zweiten fenster bei hanoi auf laden klicken ist kein problem. das editiern von spielständen ist aber nicht wirklich gut programmiert
 von mir. es passiert leicht das sachen abeschnitten werden oder ähnliches. es ist mehr eine funktion für experementier freunde. Das Tool zum übersetzten in ein ausführbares
 Programm finden sie unter: https://processing.org/ Es ist keine installation lation nowendig. Das Tool zum umprogramiern: https://processing.org/ 